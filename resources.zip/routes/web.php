<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::view('/', 'welcome');

Route::view('dashboard', 'dashboard')
    ->middleware(['auth', 'verified'])
    ->name('dashboard');

Route::view('profile', 'profile')
    ->middleware(['auth'])
    ->name('profile');

    Route::view('/contacto', 'contacto');


require __DIR__.'/auth.php';

// routes/web.php

use App\Http\Controllers\AnimalController;

// Solo propietario y administrador pueden eliminar
Route::delete('/animales/{animal}', [AnimalController::class, 'destroy'])
    ->middleware(['auth', 'role:propietario|administrador']);

// Solo veterinario puede gestionar registros médicos
Route::resource('/registros-medicos', RegistroMedicoController::class)
    ->middleware(['auth', 'role:veterinario|administrador|propietario']);

// Cualquier usuario autenticado puede ver animales
Route::get('/animales', [AnimalController::class, 'index'])
    ->middleware(['auth', 'permission:ver animales']);

    use App\Http\Controllers\InventarioController;

Route::resource('inventario', InventarioController::class)
    ->middleware(['auth']);

    
use App\Http\Controllers\RegistroMedicoController;
use App\Http\Controllers\UsuarioController;


Route::middleware(['auth'])->group(function () {
    Route::resource('animales',          AnimalController::class);
    Route::resource('inventario',        InventarioController::class);
    Route::resource('registros-medicos', RegistroMedicoController::class);
    Route::resource('usuarios',          UsuarioController::class);
});
