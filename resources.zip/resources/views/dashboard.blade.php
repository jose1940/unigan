<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            {{-- Bienvenida --}}
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 text-gray-900">
                    👋 Bienvenido, <strong>{{ auth()->user()->name }}</strong> —
                    tu rol es: <span class="text-green-600 font-semibold">
                        {{ ucfirst(auth()->user()->getRoleNames()->first() ?? 'Sin rol') }}
                    </span>
                </div>
            </div>

            {{-- Tarjetas de acceso rápido --}}
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">

                @can('ver animales')
                <a href="{{ route('animales.index') }}"
                   class="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-center">
                    <div class="text-4xl mb-2">🐄</div>
                    <h3 class="font-semibold text-gray-700">Animales</h3>
                </a>
                @endcan

                @can('ver inventario')
                <a href="{{ route('inventario.index') }}"
                   class="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-center">
                    <div class="text-4xl mb-2">📦</div>
                    <h3 class="font-semibold text-gray-700">Inventario</h3>
                </a>
                @endcan

                @can('ver registros medicos')
                <a href="{{ route('registros-medicos.index') }}"
                   class="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-center">
                    <div class="text-4xl mb-2">🩺</div>
                    <h3 class="font-semibold text-gray-700">Registros Médicos</h3>
                </a>
                @endcan

                @can('ver usuarios')
                <a href="{{ route('usuarios.index') }}"
                   class="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-center">
                    <div class="text-4xl mb-2">👥</div>
                    <h3 class="font-semibold text-gray-700">Usuarios</h3>
                </a>
                @endcan

            </div>
        </div>
    </div>
</x-app-layout>