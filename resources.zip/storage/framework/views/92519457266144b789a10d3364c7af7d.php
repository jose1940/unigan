<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 text-gray-900">
                    👋 Bienvenido, <strong><?php echo e(auth()->user()->name); ?></strong> —
                    tu rol es: <span class="text-green-600 font-semibold">
                        <?php echo e(ucfirst(auth()->user()->getRoleNames()->first() ?? 'Sin rol')); ?>

                    </span>
                </div>
            </div>

            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver animales')): ?>
                <a href="<?php echo e(route('animales.index')); ?>"
                   class="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-center">
                    <div class="text-4xl mb-2">🐄</div>
                    <h3 class="font-semibold text-gray-700">Animales</h3>
                </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver inventario')): ?>
                <a href="<?php echo e(route('inventario.index')); ?>"
                   class="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-center">
                    <div class="text-4xl mb-2">📦</div>
                    <h3 class="font-semibold text-gray-700">Inventario</h3>
                </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver registros medicos')): ?>
                <a href="<?php echo e(route('registros-medicos.index')); ?>"
                   class="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-center">
                    <div class="text-4xl mb-2">🩺</div>
                    <h3 class="font-semibold text-gray-700">Registros Médicos</h3>
                </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver usuarios')): ?>
                <a href="<?php echo e(route('usuarios.index')); ?>"
                   class="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition text-center">
                    <div class="text-4xl mb-2">👥</div>
                    <h3 class="font-semibold text-gray-700">Usuarios</h3>
                </a>
                <?php endif; ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\Unigan\resources\views/dashboard.blade.php ENDPATH**/ ?>