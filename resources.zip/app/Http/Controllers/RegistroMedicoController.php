<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RegistroMedicoController extends Controller
{
    public function index()
    {
        if (!auth()->user()->can('ver registros medicos')) {
            abort(403, 'No tienes permiso para ver registros médicos.');
        }
        return view('registros-medicos.index');
    }

    public function create()
    {
        if (!auth()->user()->can('crear registros medicos')) {
            abort(403, 'No tienes permiso para crear registros médicos.');
        }
        return view('registros-medicos.create');
    }

    public function store(Request $request)
    {
        if (!auth()->user()->can('crear registros medicos')) {
            abort(403, 'No tienes permiso para guardar registros médicos.');
        }
        return redirect()->route('registros-medicos.index')
                         ->with('success', 'Registro médico creado correctamente.');
    }

    public function show(string $id)
    {
        if (!auth()->user()->can('ver registros medicos')) {
            abort(403, 'No tienes permiso para ver este registro.');
        }
        return view('registros-medicos.show');
    }

    public function edit(string $id)
    {
        if (!auth()->user()->can('editar registros medicos')) {
            abort(403, 'No tienes permiso para editar registros médicos.');
        }
        return view('registros-medicos.edit');
    }

    public function update(Request $request, string $id)
    {
        if (!auth()->user()->can('editar registros medicos')) {
            abort(403, 'No tienes permiso para actualizar este registro.');
        }
        return redirect()->route('registros-medicos.index')
                         ->with('success', 'Registro médico actualizado correctamente.');
    }

    public function destroy(string $id)
    {
        if (!auth()->user()->hasRole('propietario|administrador')) {
            abort(403, 'No tienes permiso para eliminar registros médicos.');
        }
        return redirect()->route('registros-medicos.index')
                         ->with('success', 'Registro médico eliminado correctamente.');
    }
}