<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InventarioController extends Controller
{
    // 👁️ VER inventario — Todos los roles pueden ver
    public function index()
    {
        if (!auth()->user()->can('ver inventario')) {
            abort(403, 'No tienes permiso para ver el inventario.');
        }

        // Aquí irá tu lógica para obtener el inventario
        return view('inventario.index');
    }

    // ➕ MOSTRAR formulario de creación — Solo admin y propietario
    public function create()
    {
        if (!auth()->user()->can('gestionar inventario')) {
            abort(403, 'No tienes permiso para agregar al inventario.');
        }

        return view('inventario.create');
    }

    // 💾 GUARDAR nuevo item — Solo admin y propietario
    public function store(Request $request)
    {
        if (!auth()->user()->can('gestionar inventario')) {
            abort(403, 'No tienes permiso para guardar en el inventario.');
        }

        // Aquí irá tu lógica para guardar
        return redirect()->route('inventario.index')
                         ->with('success', 'Item agregado correctamente.');
    }

    // 👁️ VER un item específico
    public function show(string $id)
    {
        if (!auth()->user()->can('ver inventario')) {
            abort(403, 'No tienes permiso para ver este item.');
        }

        return view('inventario.show');
    }

    // ✏️ MOSTRAR formulario de edición
    public function edit(string $id)
    {
        if (!auth()->user()->can('gestionar inventario')) {
            abort(403, 'No tienes permiso para editar el inventario.');
        }

        return view('inventario.edit');
    }

    // 💾 ACTUALIZAR item
    public function update(Request $request, string $id)
    {
        if (!auth()->user()->can('gestionar inventario')) {
            abort(403, 'No tienes permiso para actualizar el inventario.');
        }

        // Aquí irá tu lógica para actualizar
        return redirect()->route('inventario.index')
                         ->with('success', 'Item actualizado correctamente.');
    }

    // 🗑️ ELIMINAR item — Solo propietario
    public function destroy(string $id)
    {
        if (!auth()->user()->hasRole('propietario')) {
            abort(403, 'Solo el propietario puede eliminar items del inventario.');
        }

        // Aquí irá tu lógica para eliminar
        return redirect()->route('inventario.index')
                         ->with('success', 'Item eliminado correctamente.');
    }
}