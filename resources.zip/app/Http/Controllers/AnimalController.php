<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AnimalController extends Controller
{
    public function index()
    {
        if (!auth()->user()->can('ver animales')) {
            abort(403, 'No tienes permiso para ver los animales.');
        }
        return view('animales.index');
    }

    public function create()
    {
        if (!auth()->user()->can('crear animales')) {
            abort(403, 'No tienes permiso para agregar animales.');
        }
        return view('animales.create');
    }

    public function store(Request $request)
    {
        if (!auth()->user()->can('crear animales')) {
            abort(403, 'No tienes permiso para guardar animales.');
        }
        // Aquí irá tu lógica para guardar
        return redirect()->route('animales.index')
                         ->with('success', 'Animal registrado correctamente.');
    }

    public function show(string $id)
    {
        if (!auth()->user()->can('ver animales')) {
            abort(403, 'No tienes permiso para ver este animal.');
        }
        return view('animales.show');
    }

    public function edit(string $id)
    {
        if (!auth()->user()->can('editar animales')) {
            abort(403, 'No tienes permiso para editar animales.');
        }
        return view('animales.edit');
    }

    public function update(Request $request, string $id)
    {
        if (!auth()->user()->can('editar animales')) {
            abort(403, 'No tienes permiso para actualizar animales.');
        }
        // Aquí irá tu lógica para actualizar
        return redirect()->route('animales.index')
                         ->with('success', 'Animal actualizado correctamente.');
    }

    public function destroy(string $id)
    {
        if (!auth()->user()->can('eliminar animales')) {
            abort(403, 'No tienes permiso para eliminar animales.');
        }
        // Aquí irá tu lógica para eliminar
        return redirect()->route('animales.index')
                         ->with('success', 'Animal eliminado correctamente.');
    }
}